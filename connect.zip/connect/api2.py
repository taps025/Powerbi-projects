from flask import Flask, request, jsonify
import sqlite3
from datetime import datetime

DB = "engagements.db"
app = Flask(__name__)

def init_db():
    conn = sqlite3.connect(DB)
    conn.execute("""
    CREATE TABLE IF NOT EXISTS engagements (
        id TEXT PRIMARY KEY,
        client_name TEXT,
        facilitator TEXT,
        facilitator_email TEXT,
        date TEXT,
        type TEXT,
        notes TEXT,
        status TEXT,
        client_code TEXT,
        reminder_sent_at TEXT
    )
    """)
    conn.commit()
    conn.close()

def query(sql, params=(), fetch=True):
    conn = sqlite3.connect(DB)
    cur = conn.cursor()
    cur.execute(sql, params)
    if fetch:
        rows = cur.fetchall()
        conn.close()
        return rows
    conn.commit()
    conn.close()

@app.route("/engagements", methods=["GET"])
def get_engagements():
    rows = query("SELECT * FROM engagements ORDER BY date DESC")
    cols = ["id","client_name","facilitator","facilitator_email","date","type","notes","status","client_code","reminder_sent_at"]
    return jsonify([dict(zip(cols, r)) for r in rows])

@app.route("/engagements/add", methods=["POST"])
def add_engagement():
    data = request.json or {}
    new_id = data.get("id") or f"E-{int(datetime.utcnow().timestamp()*1000)}"
    query("""
        INSERT INTO engagements (id, client_name, facilitator, facilitator_email,
                                 date, type, notes, status, client_code, reminder_sent_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        new_id,
        data.get("client_name", ""),
        data.get("facilitator", ""),
        data.get("facilitator_email", ""),
        data.get("date", ""),
        data.get("type", ""),
        data.get("notes", ""),
        data.get("status", "Open"),
        data.get("client_code", ""),
        None
    ), fetch=False)
    return jsonify({"message": "Saved", "id": new_id})

@app.route("/engagements/update", methods=["POST"])
def update_status():
    data = request.json or {}
    if "id" not in data or "status" not in data:
        return jsonify({"message": "Missing id or status"}), 400
    query("UPDATE engagements SET status=? WHERE id=?", (data["status"], data["id"]), fetch=False)
    return jsonify({"message": "Updated"})

@app.route("/healthz")
def health():
    return {"status": "ok"}

if __name__ == "__main__":
    print("Starting Flask API on http://127.0.0.1:5000 ...")
    init_db()
    app.run(host="0.0.0.0", port=5000, debug=True)