
# engagements_utils.py
from __future__ import annotations

import os
import io
import time
import base64
from datetime import date, datetime
from typing import Iterable

import pandas as pd
import requests


# --------------------------------------
# Configuration (edit to connect to API)
# --------------------------------------
ENGAGEMENTS_URL: str | None = None           # e.g., "https://api-minet.onrender.com/engagements"
ENGAGEMENTS_ADD_URL: str | None = None       # e.g., "https://api-minet.onrender.com/engagements/add"
ENGAGEMENTS_UPDATE_URL: str | None = None    # e.g., "https://api-minet.onrender.com/engagements/update"
ENGAGEMENTS_LOCAL_CSV = "engagement_tracker.csv"


# -------------------------------------
# Normalization
# -------------------------------------
def normalize_engagement_df(df_e: pd.DataFrame) -> pd.DataFrame:
    """Ensure standard columns and types for engagement tracker."""
    cols = [
        "ID", "Client Name", "Facilitator", "Facilitator Email",
        "Date", "Type", "Notes", "Status", "Reminder Sent At"
    ]
    if df_e is None or df_e.empty:
        return pd.DataFrame(columns=cols)

    rename_map = {
        "id": "ID",
        "client_name": "Client Name",
        "facilitator": "Facilitator",
        "facilitator_email": "Facilitator Email",
        "date": "Date",
        "type": "Type",
        "notes": "Notes",
        "status": "Status",
        "reminder_sent_at": "Reminder Sent At",
    }
    df_e = df_e.rename(columns=rename_map)

    for c in cols:
        if c not in df_e.columns:
            df_e[c] = ""

    # Coerce date to ISO (YYYY-MM-DD)
    def fmt_date(x):
        if pd.isna(x) or x == "":
            return ""
        try:
            return pd.to_datetime(str(x)).date().isoformat()
        except Exception:
            return str(x)

    df_e["Date"] = df_e["Date"].apply(fmt_date)
    df_e["Status"] = df_e["Status"].replace("", "Open")
    return df_e[cols]


# --------------------------------------
# IO: Load / Save / Update
# --------------------------------------
def load_engagements() -> pd.DataFrame:
    """Load engagements from remote API if configured; else from local CSV."""
    # Prefer remote if configured
    if ENGAGEMENTS_URL:
        try:
            r = requests.get(ENGAGEMENTS_URL, params={'_ts': int(time.time())}, timeout=20)
            if r.status_code == 200:
                return normalize_engagement_df(pd.DataFrame(r.json()))
        except Exception:
            # Silent fallback to local CSV
            pass

    # Fallback to local CSV
    if os.path.exists(ENGAGEMENTS_LOCAL_CSV):
        try:
            return normalize_engagement_df(pd.read_csv(ENGAGEMENTS_LOCAL_CSV))
        except Exception:
            pass

    return normalize_engagement_df(pd.DataFrame())


def save_engagement(
    client_name: str,
    facilitator: str,
    dt: date,
    etype: str = "",
    notes: str = "",
    facilitator_email: str = "",
) -> bool:
    """Save engagement via remote API if configured; else append to local CSV."""
    new_id = "E-" + str(int(time.time() * 1000))  # simple unique ID

    payload = {
        "id": new_id,
        "client_name": client_name,
        "facilitator": facilitator,
        "facilitator_email": (facilitator_email or "").strip(),
        "date": pd.to_datetime(dt).date().isoformat() if dt else "",
        "type": etype or "",
        "notes": notes or "",
        "status": "Open",
    }

    # Remote first
    if ENGAGEMENTS_ADD_URL:
        try:
            r = requests.post(ENGAGEMENTS_ADD_URL, json=payload, timeout=20)
            return r.status_code == 200
        except Exception:
            pass

    # Local persistence
    df_e = load_engagements()
    new_row = {
        "ID": payload["id"],
        "Client Name": payload["client_name"],
        "Facilitator": payload["facilitator"],
        "Facilitator Email": payload["facilitator_email"],
        "Date": payload["date"],
        "Type": payload["type"],
        "Notes": payload["notes"],
        "Status": payload["status"],
        "Reminder Sent At": "",
    }
    df_e = pd.concat([df_e, pd.DataFrame([new_row])], ignore_index=True)
    df_e.to_csv(ENGAGEMENTS_LOCAL_CSV, index=False)
    return True


def update_engagement_status(eng_id: str, new_status: str) -> bool:
    """Update status by ID."""
    if ENGAGEMENTS_UPDATE_URL:
        try:
            r = requests.post(ENGAGEMENTS_UPDATE_URL, json={"id": eng_id, "status": new_status}, timeout=20)
            return r.status_code == 200
        except Exception:
            pass

    # Local
    df_e = load_engagements()
    if df_e.empty:
        return False
    idx = df_e.index[df_e["ID"] == eng_id]
    if len(idx) == 0:
        return False
    df_e.loc[idx, "Status"] = new_status
    df_e.to_csv(ENGAGEMENTS_LOCAL_CSV, index=False)
    return True


def mark_reminder_sent(eng_ids: Iterable[str]) -> None:
    """Mark reminder sent timestamp for given engagement IDs (local only)."""
    df_e = load_engagements()
    if df_e.empty:
        return
    now_iso = datetime.now().isoformat(timespec="seconds")
    df_e.loc[df_e["ID"].isin(list(eng_ids)), "Reminder Sent At"] = now_iso
    df_e.to_csv(ENGAGEMENTS_LOCAL_CSV, index=False)


# --------------------------------------
# Export helpers (robust across versions)
# --------------------------------------
def df_to_excel_bytes(df: pd.DataFrame, sheet_name: str = "Data") -> bytes:
    """
    Convert a DataFrame to an Excel file in-memory and return bytes.
    Uses a BytesIO buffer (no reliance on ExcelWriter internals).
    """
    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name=sheet_name)

        # Best-effort autofit column widths (safe to ignore failures)
        try:
            ws = writer.book[sheet_name]
            for column_cells in ws.iter_cols(min_row=1, max_row=ws.max_row, max_col=ws.max_column):
                max_len = 0
                for cell in column_cells:
                    val_len = len(str(cell.value)) if cell.value is not None else 0
                    if val_len > max_len:
                        max_len = val_len
                ws.column_dimensions[column_cells[0].column_letter].width = max_len + 2
        except Exception:
            pass

    buffer.seek(0)
    return buffer.getvalue()


# --------------------------------------
# Logo helper
# --------------------------------------
def embed_image_base64(image_path: str) -> str:
    """Return a data URI for an image, or empty string if not found."""
    if not os.path.exists(image_path):
        return ""
    with open(image_path, "rb") as f:
        data = f.read()
    lower = image_path.lower()
    if lower.endswith(".png"):
        mime = "image/png"
    elif lower.endswith(".jpg") or lower.endswith(".jpeg"):
        mime = "image/jpeg"
    else:
        mime = "image/png"
    b64 = base64.b64encode(data).decode("utf-8")
    return f"data:{mime};base64,{b64}"
