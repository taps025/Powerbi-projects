from flask import Flask, jsonify, request
from datetime import datetime
import json
import os
import re
from threading import RLock

app = Flask(__name__)

# ------------------------------------------------------------------------
# CONFIG
# ------------------------------------------------------------------------
DATA_FILE = "data.json"  # Will be created automatically if missing
ALLOWED_STATUS_VALUES = {"CROSS-SELL", "SHARED CLIENT"}

# In-memory cache + lock
_data = []
_lock = RLock()


# ------------------------------------------------------------------------
# HELPER FUNCTIONS
# ------------------------------------------------------------------------
def canon(s: str) -> str:
    if s is None:
        return ""
    s = re.sub(r"[`.,:\-\[\]]+", "", str(s))
    s = re.sub(r"\s+", " ", s).strip()
    return s.upper()


def load_data():
    """Load JSON file into memory."""
    global _data
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            _data = json.load(f)
    else:
        _data = []


def save_data():
    """Save in-memory data back to JSON file."""
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(_data, f, indent=2, ensure_ascii=False)


def find_by_client(sheet: str, code: str):
    """Find a record by sheet + client code."""
    code = code.lower()
    for row in _data:
        if row.get("SOURCE_SHEET") == sheet and str(row.get("CLIENT CODE", "")).lower() == code:
            return row
    return None


# ------------------------------------------------------------------------
# ROUTES
# ------------------------------------------------------------------------
@app.route("/", methods=["GET"])
def home():
    return "✅ API is running (JSON-only). Use GET /data, POST /update, POST /seed"


@app.route("/health", methods=["GET"])
def health():
    with _lock:
        return jsonify({
            "status": "ok",
            "mode": "json-file",
            "file": os.path.abspath(DATA_FILE),
            "exists": os.path.exists(DATA_FILE),
            "rows": len(_data)
        })


@app.route("/data", methods=["GET"])
def get_data():
    with _lock:
        return jsonify(_data)


@app.route("/seed", methods=["POST"])
def seed():
    """
    Completely replace all data.
    Body must be a JSON array.
    """
    body = request.get_json(silent=True)
    if not isinstance(body, list):
        return jsonify({"status": "error", "message": "Expected JSON array"}), 400

    # Validate each row contains sheet + client code
    for i, row in enumerate(body):
        if "SOURCE_SHEET" not in row or "CLIENT CODE" not in row:
            return jsonify({
                "status": "error",
                "message": f"Row {i} missing SOURCE_SHEET or CLIENT CODE"
            }), 400

    with _lock:
        global _data
        _data = body
        save_data()

    return jsonify({"status": "success", "rows_loaded": len(_data)})


@app.route("/update", methods=["POST"])
def update():
    """
    {
      "sheet": "corp",
      "client_code": "C001",
      "column": "Status",
      "new_value": "Shared Client"
    }
    """
    body = request.get_json(silent=True) or {}

    sheet = body.get("sheet")
    code = (body.get("client_code") or "").strip()
    col = body.get("column")
    val = body.get("new_value")

    if not all([sheet, code, col]):
        return jsonify({"status": "error", "message": "Missing sheet/client_code/column"}), 400

    if canon(col) == "STATUS":
        if canon(str(val)) not in ALLOWED_STATUS_VALUES:
            return jsonify({
                "status": "error",
                "message": "Invalid status. Use 'Cross-Sell' or 'Shared Client'."
            }), 400

    with _lock:
        row = find_by_client(sheet, code)
        if not row:
            return jsonify({
                "status": "error",
                "message": f"Client Code '{code}' not found in sheet '{sheet}'"
            }), 404

        # Update target field
        row[col] = val

        # Update timestamp
        row["STATUS_UPDATED_AT"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        save_data()

    return jsonify({
        "status": "success",
        "message": f"Updated {col} for {code}",
        "sheet": sheet,
        "client_code": code,
        "column": col,
        "new_value": val,
        "updated_at": row["STATUS_UPDATED_AT"]
    })


# ------------------------------------------------------------------------
# BOOTSTRAP
# ------------------------------------------------------------------------
if __name__ == "__main__":
    load_data()
    app.run(host="0.0.0.0", port=5000)