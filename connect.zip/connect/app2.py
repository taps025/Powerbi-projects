# app2.py
# ------------------------------------------------------------
# Engagements viewer (API-first; optional CSV fallback)
# ------------------------------------------------------------
import os
import time
import requests
import streamlit as st
import pandas as pd
from pathlib import Path

# =========================
# CONFIG
# =========================
TITLE_FONT_SIZE_REM = 10.0
LOGO_WIDTH_PX = 150
DUE_SOON_DAYS = 7

# Optional CSV fallback (disabled unless env enables it)
ALLOW_LOCAL_CSV = os.environ.get("ALLOW_LOCAL_CSV", "false").lower() == "true"
ENGAGEMENTS_LOCAL_CSV = os.environ.get("ENGAGEMENTS_LOCAL_CSV", "engagement_tracker.csv")

def _join(base: str, path: str) -> str:
    return base.rstrip('/') + '/' + path.lstrip('/')

# API BASE
ENG_API_BASE = os.environ.get("ENG_API_BASE", "http://127.0.0.1:5000")
ENGAGEMENTS_URL = os.environ.get("ENGAGEMENTS_URL", _join(ENG_API_BASE, "/engagements")) or None

st.set_page_config(page_title="CROSS-SELLING ENGAGEMENT TRACKER", layout="wide")

# =========================
# Logo helper
# =========================
def find_logo(candidate_name: str = "minet.png"):
    candidates = []
    cwd = Path.cwd()
    candidates += [cwd / candidate_name, cwd / "images" / candidate_name]
    try:
        script_dir = Path(__file__).parent
    except NameError:
        script_dir = None
    if script_dir:
        candidates += [
            script_dir / candidate_name,
            script_dir.parent / candidate_name,
            script_dir / "images" / candidate_name,
        ]
    for p in candidates:
        if p.exists() and p.is_file():
            return p
    return None

# =========================
# Header
# =========================
def render_header_inline(title_text: str):
    st.markdown(
        f"""
        <style>
        .header-title {{
            font-size: {TITLE_FONT_SIZE_REM}rem;
            font-weight: bold;
            line-height: 1.1;
            margin: 10;
        }}
        .header-block {{
            margin-bottom: 0.5rem;
        }}
        </style>
        """,
        unsafe_allow_html=True,
    )
    with st.container():
        col_logo, col_title = st.columns([1, 6], vertical_alignment="center")
        with col_logo:
            logo_path = find_logo("minet.png")
            if logo_path:
                st.image(str(logo_path), width=LOGO_WIDTH_PX)
        with col_title:
            st.markdown(
                f"<div class='header-block'><h2 class='header-title'>{title_text}</h2></div>",
                unsafe_allow_html=True,
            )

# ========================
# API fetch with retry
# ========================
def get_with_retries(url: str, params=None, retries=2, backoff=0.7, timeout=12):
    last_err = None
    for i in range(retries + 1):
        try:
            return requests.get(url, params=params, timeout=timeout)
        except Exception as e:
            last_err = e
            if i < retries:
                time.sleep(backoff * (2 ** i))
    raise last_err

# =========================
# Normalize API data
# =========================
def normalize_engagement_df(df_e: pd.DataFrame) -> pd.DataFrame:
    cols = [
        "ID", "Client Name", "Facilitator", "Facilitator Email",
        "Date", "Type", "Notes", "Status", "Flag", "Reminder Sent At",
    ]
    if df_e.empty:
        return pd.DataFrame(columns=cols)

    rename_map = {
        "id": "ID",
        "client_name": "Client Name",
        "facilitator": "Facilitator",
        "facilitator_email": "Facilitator Email",
        "date": "Date",
        "type": "Type",
        "notes": "Notes",
        "status": "Status",
        "flag": "Flag",
        "reminder_sent_at": "Reminder Sent At",
    }

    df = df_e.copy()
    df.columns = [c.strip() for c in df.columns]
    df = df.rename(columns=rename_map)

    for c in cols:
        if c not in df.columns:
            df[c] = ""

    def fix_date(x):
        if pd.isna(x) or str(x).strip() == "":
            return ""
        try:
            return pd.to_datetime(str(x)).date().isoformat()
        except Exception:
            return str(x)

    df["Date"] = df["Date"].apply(fix_date)
    df["Status"] = df["Status"].replace("", "Open")

    return df[cols]

# =========================
# Load engagements
# =========================
def load_engagements() -> pd.DataFrame:
    if ENGAGEMENTS_URL:
        try:
            r = get_with_retries(ENGAGEMENTS_URL, params={"_ts": int(time.time())})
            if r.status_code == 200:
                data = r.json()
                if isinstance(data, list):
                    return normalize_engagement_df(pd.DataFrame(data))
                else:
                    st.error("Unexpected API response format (expected list).")
            else:
                st.error(f"Failed to fetch engagements (HTTP {r.status_code}).")
                st.caption((r.text or "")[:300])
        except Exception as e:
            st.error("Error connecting to engagements API.")
            st.caption(str(e))

    if not ALLOW_LOCAL_CSV:
        return normalize_engagement_df(pd.DataFrame())

    # CSV fallback
    locs = [
        (Path(__file__).parent / ENGAGEMENTS_LOCAL_CSV) if "__file__" in globals() else None,
        Path.cwd() / ENGAGEMENTS_LOCAL_CSV,
    ]
    for p in [x for x in locs if x]:
        if p.exists():
            try:
                return normalize_engagement_df(pd.read_csv(p))
            except Exception:
                pass

    return normalize_engagement_df(pd.DataFrame())

# =========================
# Flag logic
# =========================
def compute_flags(df_in: pd.DataFrame) -> pd.DataFrame:
    df = df_in.copy()
    today = pd.Timestamp.today().normalize()
    dt = pd.to_datetime(df["Date"], errors="coerce")

    is_closed = df["Status"].astype(str).str.lower() == "closed"
    is_open = ~is_closed

    df["Flag"] = ""
    df.loc[is_closed, "Flag"] = "Actioned"

    delta = (dt - today).dt.days

    df.loc[is_open & (delta < 0), "Flag"] = "Late"
    df.loc[is_open & (delta == 0), "Flag"] = "Due soon"
    df.loc[is_open & (delta > 0) & (delta <= DUE_SOON_DAYS), "Flag"] = "Due soon"
    df.loc[is_open & (delta > DUE_SOON_DAYS), "Flag"] = "Upcoming"

    return df

# =========================
# Flag styling
# =========================
def style_flags(df_in: pd.DataFrame, cols):
    def flag_style(v):
        if not isinstance(v, str):
            return ""
        val = v.lower()
        if val == "late":
            return "background-color:#dc2626;color:white;font-weight:600;"
        if val == "due soon":
            return "background-color:#f59e0b;color:black;font-weight:600;"
        if val == "actioned":
            return "background-color:#16a34a;color:white;font-weight:600;"
        if val == "upcoming":
            return "background-color:#93c5fd;color:black;font-weight:600;"
        return ""
    return df_in[cols].style.applymap(flag_style, subset=["Flag"])

# =========================
# UI
# =========================
render_header_inline("CROSS-SELLING ENGAGEMENT TRACKER")

df = load_engagements()
if df.empty:
    st.info("No engagement entries found.")
    st.stop()

df = compute_flags(df)

# Build month range
date_vals = pd.to_datetime(df["Date"], errors="coerce")
min_date = date_vals.min()
max_date = date_vals.max()

if pd.isna(min_date) or pd.isna(max_date):
    base = pd.Timestamp.today().replace(day=1)
    min_date = max_date = base

periods = pd.period_range(min_date.to_period("M"), max_date.to_period("M"), freq="M")

def month_label(p): return p.to_timestamp().strftime("%B %Y")
month_labels = [month_label(p) for p in periods]
label_to_period = {month_label(p): p for p in periods}

# Sidebar filters (CLEAN — no API info)
st.sidebar.header("FILTERS")
facilitators = sorted([f for f in df["Facilitator"].unique() if str(f).strip() != ""])
facilitator_sel = st.sidebar.selectbox("Facilitator", ["(All)"] + facilitators)

status_options = ["Open", "Closed"]
status_sel = st.sidebar.multiselect("Status", status_options, default=status_options)

months_sel = st.sidebar.multiselect("Months", month_labels, default=month_labels)

# Apply filters
df_view = df.copy()

# Facilitator filter
if facilitator_sel != "(All)":
    df_view = df_view[df_view["Facilitator"] == facilitator_sel]

# Status filter — SKIP if user cleared selection (show all instead of empty)
if status_sel:
    df_view = df_view[df_view["Status"].isin(status_sel)]

# Months filter — SKIP if user cleared selection (show all instead of empty)
if months_sel:
    selected_periods = {label_to_period[m] for m in months_sel if m in label_to_period}
    df_view["_period"] = pd.to_datetime(df_view["Date"], errors="coerce").dt.to_period("M")
    df_view = df_view[df_view["_period"].isin(selected_periods)]
    df_view = df_view.drop(columns=["_period"])

# Sort newest first
df_view["_date"] = pd.to_datetime(df_view["Date"], errors="coerce")
df_view = df_view.sort_values("_date", ascending=False).drop(columns=["_date"])

# Presentation
df_display = df_view.rename(columns={"Date": "Date of cross-sell engagement"})
df_display["Date of cross-sell engagement"] = (
    pd.to_datetime(df_display["Date of cross-sell engagement"], errors="coerce")
    .dt.strftime("%d %B %Y")
    .fillna("")
)

cols = ["Facilitator", "Client Name", "Date of cross-sell engagement",
        "Type", "Notes", "Status", "Flag"]

if df_display.empty:
    st.info("No engagements match the current filters.")
else:
    styled = style_flags(df_display, cols)
    st.markdown(styled.to_html(), unsafe_allow_html=True)
