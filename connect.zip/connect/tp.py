
# main.py
import os, json, time, threading
from datetime import date
from typing import Optional, List, Dict, Any

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

# =========================
# Config
# =========================
# File where engagements are stored. Must be inside the Persistent Disk mount path.
ENG_FILE = os.environ.get("ENGAGEMENTS_FILE", "/var/data/engagements.json")

# Allow calls from your two dashboards (you can add more, comma-separated)
DEFAULT_ORIGINS = (
    "https://cross-sell-dashboard.onrender.com,"
    "https://mds-cross-selling-tracker.onrender.com"
)
ALLOWED_ORIGINS = [o.strip() for o in os.environ.get("ALLOWED_ORIGINS", DEFAULT_ORIGINS).split(",")]

app = FastAPI(title="Engagements API (file-backed)", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS if ALLOWED_ORIGINS != ["*"] else ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-process lock to guard file access across concurrent requests
_lock = threading.Lock()

# =========================
# Models
# =========================
class EngagementIn(BaseModel):
    id: Optional[str] = Field(default=None, description="If omitted, API generates E-<timestamp_ms>")
    client_name: str
    facilitator: str
    facilitator_email: Optional[str] = None
    date: Optional[date] = None
    type: Optional[str] = None
    notes: Optional[str] = None
    status: Optional[str] = "Open"

class EngagementStatus(BaseModel):
    id: str
    status: str

# =========================
# Helpers
# =========================
def _ensure_file():
    """Create the JSON file if missing; initialize as empty list."""
    os.makedirs(os.path.dirname(ENG_FILE), exist_ok=True)
    if not os.path.exists(ENG_FILE):
        with open(ENG_FILE, "w", encoding="utf-8") as f:
            json.dump([], f)

def _read_all() -> List[Dict[str, Any]]:
    _ensure_file()
    with open(ENG_FILE, "r", encoding="utf-8") as f:
        try:
            data = json.load(f)
            return data if isinstance(data, list) else []
        except json.JSONDecodeError:
            return []

def _write_all(items: List[Dict[str, Any]]):
    # Atomic replace to avoid partial writes
    tmp = ENG_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(items, f, ensure_ascii=False)
    os.replace(tmp, ENG_FILE)

# =========================
# Routes
# =========================
@app.on_event("startup")
def _startup():
    _ensure_file()

@app.get("/health")
def health():
    return {"status": "ok", "file": ENG_FILE, "count": len(_read_all())}

@app.get("/engagements")
def list_engagements() -> List[Dict[str, Any]]:
    with _lock:
        items = _read_all()
        # Sort newest first (by date, then by id)
        def sort_key(x):
            d = x.get("date") or ""
            return (d, x.get("id", ""))
        items.sort(key=sort_key, reverse=True)
        return items

@app.post("/engagements")
def add_engagement(e: EngagementIn):
    with _lock:
        items = _read_all()
        eid = e.id or f"E-{int(time.time()*1000)}"
        item = {
            "id": eid,
            "client_name": e.client_name,
            "facilitator": e.facilitator,
            "facilitator_email": e.facilitator_email,
            "date": e.date.isoformat() if e.date else None,
            "type": e.type,
            "notes": e.notes,
            "status": e.status or "Open",
            "reminder_sent_at": None
        }
        items.append(item)
        _write_all(items)
    return {"message": "ok", "id": eid}

@app.post("/engagements/update")
def update_status(p: EngagementStatus):
    with _lock:
        items = _read_all()
        found = False
        for it in items:
            if it.get("id") == p.id:
                it["status"] = p.status
                found = True
                break
        if not found:
            raise HTTPException(status_code=404, detail="Not found")
        _write_all(items)
    return {"message": "ok"}

