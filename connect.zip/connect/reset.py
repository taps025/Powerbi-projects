# reset_db.py
import sqlite3
import os

DB = os.environ.get("DB", "engagements.db")

conn = sqlite3.connect(DB)
cur = conn.cursor()

# 1) Delete all rows but keep the table/schema
cur.execute("DELETE FROM engagements;")
conn.commit()

# 2) Optional: reclaim file space
cur.execute("VACUUM;")
conn.commit()

conn.close()
print("All data deleted. Schema preserved.")